<?php
session_start();
$host="localhost"; $user="root"; $pass=""; $db="library_db";
$conn=new mysqli($host,$user,$pass);
if($conn->connect_error) die("Database connection failed: ".$conn->connect_error);
$conn->query("CREATE DATABASE IF NOT EXISTS `$db`");
$conn->select_db($db);
$conn->set_charset("utf8mb4");
$conn->query("CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(150) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
$conn->query("CREATE TABLE IF NOT EXISTS admins(id INT AUTO_INCREMENT PRIMARY KEY,username VARCHAR(50) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL)");
$conn->query("CREATE TABLE IF NOT EXISTS books(id INT AUTO_INCREMENT PRIMARY KEY,title VARCHAR(200) NOT NULL,author VARCHAR(150) NOT NULL,isbn VARCHAR(50),category VARCHAR(100),quantity INT NOT NULL DEFAULT 1,available INT NOT NULL DEFAULT 1,description TEXT)");
$conn->query("CREATE TABLE IF NOT EXISTS issues(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,book_id INT NOT NULL,issue_date DATE NOT NULL,due_date DATE NOT NULL,return_date DATE NULL,status ENUM('Pending','Issued','Returned','Rejected') DEFAULT 'Pending',FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE)");
$conn->query("CREATE TABLE IF NOT EXISTS messages(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100),email VARCHAR(150),message TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
$check=$conn->query("SELECT id FROM admins LIMIT 1");
if($check && $check->num_rows===0){$hash=password_hash("admin123",PASSWORD_DEFAULT);$stmt=$conn->prepare("INSERT INTO admins(username,password) VALUES('admin',?)");$stmt->bind_param("s",$hash);$stmt->execute();}
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function require_login(){if(empty($_SESSION['user_id'])){header("Location: login.php");exit;}}
function require_admin(){if(empty($_SESSION['admin_id'])){header("Location: login.php");exit;}}
?>